FunTarget Cordova project (auto-generated)

Contents:
 - www/index.html  (your game HTML)
 - config.xml
 - package.json
 - build_termux.sh  (a helper script to try building inside Termux; may require SDK/tools setup)

Usage:
1) Copy this folder to your Termux home. Place your index.html into www/ (already included).
2) Install cordova/npm/android-sdk/gradle as needed in Termux (not fully automated).
3) Run: bash build_termux.sh

Note: Building on Android/Termux can be fragile. If building fails, consider using GitHub Actions (CI) to produce the APK remotely.
