// MainActivity.kt
package com.yourcompany.funtarget

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient 

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 1. WebView को ID से ढूंढना (my_webview)
        val webView: WebView = findViewById(R.id.my_webview)

        // 2. JavaScript को सक्षम करना
        webView.settings.javaScriptEnabled = true
        
        // 3. WebViewClient सेट करना ताकि लिंक ऐप के अंदर ही खुलें
        webView.webViewClient = WebViewClient()

        // 4. अपनी वेबसाइट का URL लोड करना
        val websiteUrl = "https://narayanbalai100-a11y.github.io/FunTargetBuild/"
        webView.loadUrl(websiteUrl)
    }
}
