#!/usr/bin/env bash
set -e
echo "This script attempts to create a Cordova project and build an APK on Termux."
echo "It only automates a best-effort set of steps; Termux environment may vary."
PROJECT_DIR="$HOME/FunTargetCordova_local"
mkdir -p "$PROJECT_DIR"
cd "$PROJECT_DIR"

if ! command -v cordova >/dev/null 2>&1; then
  echo "cordova not found. Install with: npm install -g cordova"
  exit 1
fi

# create project if not exists
if [ ! -f config.xml ]; then
  cordova create . com.funtarget.app FunTarget || true
fi

# copy www contents
rm -rf www
mkdir -p www
cp -r "$PWD/../www"/* www/ || true

# add android platform (use 12.0.1 for better Termux compatibility)
cordova platform rm android >/dev/null 2>&1 || true
cordova platform add android@12.0.1

# try build
cordova build android --debug
echo "If build succeeded, APK will be at platforms/android/app/build/outputs/apk/debug/app-debug.apk"
